package com.gaoju;

import java.io.*;

/**
 * @ClassName: ComputerTeacher
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/27 14:47
 * @URL：https://github.com/GaoHaiNB
 */
public class ComputerTeacher extends Teacher implements Serializable{
    @Override
    public String work() {
        return "我是计算机老师，一边演示，一边讲解";
    }
    public ComputerTeacher(String name, String addr, String project, int age) {
        super(name, addr, project, age);
    }
    public static void main(String[] args) {
        FileStream fileStream = new FileStream();
        fileStream.fxlh();
    }
}
