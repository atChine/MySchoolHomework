package com.gaoju;

import java.io.*;

/**
 * @ClassName: FileStream
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/27 15:10
 * @URL：https://github.com/GaoHaiNB
 */
public class FileStream implements Serializable{
    //1.xlh=序列化
    public  static void xlh(){
        ObjectOutputStream ops = null;
        try {
            //创建ObjectOutputStream流对象来完成序列化
            ops = new ObjectOutputStream(new FileOutputStream("D:\\Software\\IDEA\\JAVA_project\\综合练习3-抽象类\\src\\wbb"));
            //指定要序列化(输出)的对象
            ComputerTeacher computerTeacher = new ComputerTeacher
                    ("王冰冰", "吉林", "计算机老师", 31);
            ops.writeObject(computerTeacher);
            System.out.println("序列化成功");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("序列化失败");
        } finally {
            try {
                //关闭流
                ops.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    //反序列化
    public static void fxlh(){
        ObjectInputStream oin=null;
        try {
            oin = new ObjectInputStream(new FileInputStream("D:\\Software\\IDEA\\JAVA_project\\综合练习3-抽象类\\src\\wbb"));
            ComputerTeacher computerTeacher=(ComputerTeacher) oin.readObject();
            System.out.println(computerTeacher.toString());
            System.out.println(computerTeacher.work());
            System.out.println("反序列化成功");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("反序列化失败");
        }finally {
            try {
                oin.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
