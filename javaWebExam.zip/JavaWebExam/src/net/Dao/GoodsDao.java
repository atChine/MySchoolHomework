package net.Dao;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import net.beans.Goods;
import net.utils.C3P0Util;

public class GoodsDao{
	//��ѯ����
	public List<Goods> findAllGoods(){
		Connection connection = C3P0Util.getCon();
		QueryRunner queryRunner = new QueryRunner();
		String sql="select * from goods";
		List<Goods> FindAlllist = new ArrayList<>();
		try {
			FindAlllist=queryRunner.query(connection, sql, new BeanListHandler<Goods>(Goods.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("��ѯʧ��");
		}finally {
			C3P0Util.closeAll(connection);
		}
		
		return FindAlllist;	
	}
	//�����ֲ�ѯ
	public List<Goods> findNameGoods(String name){
		Connection connection = C3P0Util.getCon();
		QueryRunner queryRunner = new QueryRunner();
		List<Goods> list = null;
		String sql="select * from goods where name=?";
		
		try {
			list=queryRunner.query(connection, sql, new BeanListHandler<Goods>(Goods.class),name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("�����ֲ�ѯʧ��");
		}finally {
			C3P0Util.closeAll(connection);
		}
		return list;
	}
	//ɾ��
	public int deleteGoods(String name){
		int i=0;
		String sql="delete from goods where name=?";
		Connection con = C3P0Util.getCon();
		QueryRunner queryRunner = new QueryRunner();
		try {
			i = queryRunner.update(con, sql, name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("ɾ��ʧ��");
		}finally {
			C3P0Util.closeAll(con);
		}
		return i;
	}
	//����
	public int addGoods(Goods goods){
		int i=0;
		String sql="insert into goods values(null,?,?,?)";
		Connection connection = C3P0Util.getCon();
		QueryRunner queryRunner = new QueryRunner();
		try {
			i = queryRunner.update(connection, sql, goods.getName(),goods.getPro(),goods.getPrice());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("����ʧ��");
		}
		return i;
	}
	//��id��
	public int updateGoods(String name,Goods goods){
		int i=0;
		String sql="update goods set pro=?,price=? where name=?";
		Connection connection = C3P0Util.getCon();
		QueryRunner queryRunner = new QueryRunner();
		try {
			i=queryRunner.update(connection, sql,goods.getPro(),goods.getPrice(),name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("�޸�ʧ��");
		}finally {
			C3P0Util.closeAll(connection);
		}
		return i;
		
	}
}
