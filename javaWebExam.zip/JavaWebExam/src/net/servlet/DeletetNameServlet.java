package net.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.Dao.GoodsDao;
import net.beans.Goods;

/**
 * Servlet implementation class SelectNameServlet
 */
@WebServlet("/servlet/DelectNameServlet")
public class DeletetNameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeletetNameServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
//		Goods goods = new Goods();
		GoodsDao goodsDao = new GoodsDao();
		int i = goodsDao.deleteGoods(name);
		if(i >= 1){
			System.out.println("ɾ���ɹ�");
			response.sendRedirect("IndexServlet");
		}else{
			response.sendRedirect("../index.jsp");
			System.out.println("ɾ��ʧ��");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
