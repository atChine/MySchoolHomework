package net.servlet;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.Dao.GoodsDao;
import net.beans.Goods;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/servlet/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pro = request.getParameter("pro");
		String price2 = request.getParameter("price");
		BigDecimal price = new BigDecimal(price2);
		HttpSession session = request.getSession();
		Goods goods2 = (Goods) session.getAttribute("goods");
		Goods goods = new Goods(pro, price);
		String name = goods2.getName();
		GoodsDao goodsDao = new GoodsDao();
		int i = goodsDao.updateGoods(name, goods);
		if(i>0){
			response.sendRedirect("servlet/IndexServlet");
		}else {
			response.sendRedirect("../update.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
