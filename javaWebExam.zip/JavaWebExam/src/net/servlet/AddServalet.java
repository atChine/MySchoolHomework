package net.servlet;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.Dao.GoodsDao;
import net.beans.Goods;

/**
 * Servlet implementation class AddServalet
 */
@WebServlet("/servlet/AddServalet")
public class AddServalet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddServalet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String pro = request.getParameter("pro");
		String price02 = request.getParameter("price");
		int i=0;
		BigDecimal price = new BigDecimal(price02);
		GoodsDao goodsDao = new GoodsDao();
		Goods goods = new Goods(name, pro, price);
		 i= goodsDao.addGoods(goods);
		if(i>0){
			response.sendRedirect("IndexServlet");
		}else {
			response.sendRedirect("../addGoods.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
