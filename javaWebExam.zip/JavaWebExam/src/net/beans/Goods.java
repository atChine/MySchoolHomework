package net.beans;

import java.math.BigDecimal;

public class Goods {
	private String id;
	private String name;
	private String pro;
	private BigDecimal price;
	public Goods(String id, String name, String pro, BigDecimal price) {
		super();
		this.id = id;
		this.name = name;
		this.pro = pro;
		this.price = price;
	}
	
	public Goods(String name, String pro, BigDecimal price) {
		super();
		this.name = name;
		this.pro = pro;
		this.price = price;
	}
	

	public Goods(String pro, BigDecimal price) {
		super();
		this.pro = pro;
		this.price = price;
	}

	public Goods() {
		super();
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPro() {
		return pro;
	}
	public void setPro(String pro) {
		this.pro = pro;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	
}
