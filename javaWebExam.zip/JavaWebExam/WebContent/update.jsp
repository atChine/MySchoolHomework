<%@page import="net.beans.Goods"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
	Goods goods=(Goods)session.getAttribute("goods");
%>
<h2>编辑产品信息</h2>
<form action="servlet/UpdateServlet" method="post">
	pro:<input type="text" name="pro" value="<%= goods.getPro()%>"><br>
	price:<input type="text" name="price" value="<%= goods.getPrice()%>"><br>
	<input type="submit" value="修改"> 
</form>
</body>
</html>