<%@page import="net.beans.Goods"%>
<%@page import="java.util.List"%>
<%@page import="net.Dao.GoodsDao"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
<h2>主页</h2>
<a href="addGoods.jsp" >增加产品信息</a>
<form action="servlet/FindNameServlet" method="post">
	输入产品名字:<input type="text" name="name" >
	<input type="submit" value="查找"> 
</form>
<table border="1px">
	<tr><td>序列号</td><td>产品名</td><td>产地</td><td>价格</td><td>编辑</td><td>删除</td></tr>
	<c:forEach items="${list }" var="list" varStatus="id">
	<tr align="center" <c:if test="${id.count % 2==0}">style="background: pink;"</c:if>>
		<td>${list.getId()}</td>
		<td>${list.getName()}</td>
		<td>${list.getPro()}</td>
		<td>${list.getPrice()}</td>
		<td><a href="update.jsp?">编辑</a></td>
		<td><a href="servlet/DelectNameServlet?name=${list.getName() }">删除</a></td>
	</tr>
	</c:forEach>
</table>
</body>
</html>