<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
<h2>增加</h2>
<form action="servlet/AddServalet" method="post">
name:<input type="text" name="name"><br>
pro :<input type="text" name="pro"><br>
price:<input type="text" name="price"><br>
<input type="submit" value="增加">
</form>
</body>
</html>