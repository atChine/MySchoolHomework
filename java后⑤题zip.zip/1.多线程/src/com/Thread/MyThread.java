package com.Thread;

public class MyThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<1000;i++){
			System.out.println(i+"*"+i+"*"+i+"="+i*i*i);
		}
	}
	
}
