package com.Thread;

public class TestMyThread {
	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		Thread thread = new Thread(myThread);
		thread.start();
		for(int i=0;i<2000;i++){
			System.out.println(i+"*"+i+"="+i*i);
		}
	}
}
