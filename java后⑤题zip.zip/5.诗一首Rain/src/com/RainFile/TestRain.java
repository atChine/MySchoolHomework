package com.RainFile;

import java.io.IOException;

public class TestRain {
	public static void main(String[] args) {
		Rain rain = new Rain();
		rain.Writer();
		try {
			rain.copy();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rain.cName();
	}
}
