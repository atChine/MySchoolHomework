package com.Conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class MysqlDemo {
	private static final String URL="jdbc:mysql://localhost:3306/school?";
	private static final String NMAE="root";
	private static final String PASSWORD="123";
	
	public static Connection getConnect(){
		try {
			Class.forName("com.mysql.jdbc.Driver");//��������
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection conn=null;
		try {
			//�������ݿ�
			conn = DriverManager.getConnection(URL,NMAE,PASSWORD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	public static void closeAll(ResultSet resultSet,Statement statement,Connection connection) throws SQLException{
		if (resultSet!=null){
            resultSet.close();
        }
        if (statement!=null){
            statement.close();
        }
        if (connection!=null){
            connection.close();
        }
	}
	public static void main(String[] args) {
		
		MysqlDemo.getConnect();
	}
}
