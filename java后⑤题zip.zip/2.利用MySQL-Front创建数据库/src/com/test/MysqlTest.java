package com.test;

import java.sql.SQLException;

import com.dao.*;


public class MysqlTest {
	public static void main(String[] args) throws SQLException {
		ClearDao.clear();
		AddDao.add();
		FindDao.find();
		Update.update();
		FindDao.find();
		DeleteDao.delete();
		FindDao.find();
	}
}
