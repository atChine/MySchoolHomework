package com.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.Conn.MysqlDemo;

public abstract class DeleteDao {
	public static void delete() throws SQLException{
		Connection connect = MysqlDemo.getConnect();
		Statement statement = (Statement)connect.createStatement();
		String sql="DELETE  FROM student02 WHERE sno='20210003'";
		int row = statement.executeUpdate(sql);
		if(row>0){
			System.out.println("ɾ���ɹ�");
		}
		
		MysqlDemo.closeAll(null, statement, connect);
	}		
}
