package com.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.Conn.MysqlDemo;

public abstract class ClearDao {
	public static void clear() throws SQLException{
			Connection connect = MysqlDemo.getConnect();
			Statement statement = (Statement)connect.createStatement();
			String sql="DELETE FROM student02 ";
			int row = statement.executeUpdate(sql);
			if(row>0){
				System.out.println("����ɹ�");
			}
			
			MysqlDemo.closeAll(null, statement, connect);
		}
	}
