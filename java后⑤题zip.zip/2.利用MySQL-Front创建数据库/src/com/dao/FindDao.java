package com.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.Conn.MysqlDemo;

public abstract class FindDao {
	public static void find() throws SQLException{
			String sql="select * from student02";
		Connection connect = MysqlDemo.getConnect();
		Statement statement = (Statement)connect.createStatement();
		ResultSet resultSet = statement.executeQuery(sql);
		while(resultSet.next()){
			System.out.print(resultSet.getString(1)+" ");
			System.out.print(resultSet.getString(2)+" ");
			System.out.print(resultSet.getString(3)+" ");
			System.out.print(resultSet.getInt(4)+" ");
			System.out.println("");
		}	
		MysqlDemo.closeAll(resultSet, statement, connect);
	}
}
