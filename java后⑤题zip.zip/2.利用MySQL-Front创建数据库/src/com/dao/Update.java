package com.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.Conn.MysqlDemo;

public abstract class Update {
	public static void update() throws SQLException{
		Connection connect = MysqlDemo.getConnect();
		Statement statement = (Statement)connect.createStatement();
		String sql="update student02 set age=18 where sno='20210004'";
		int row = statement.executeUpdate(sql);
		if(row>0){
			System.out.println("�޸ĳɹ�");
		}
		
		MysqlDemo.closeAll(null, statement, connect);	
	}	
}
