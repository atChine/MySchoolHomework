package com.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.Conn.MysqlDemo;

public abstract class AddDao {
	public static void add() throws SQLException{
		Connection connect = MysqlDemo.getConnect();
		Statement statement = (Statement)connect.createStatement();
		String sql01="insert into student02 values ('��һ','20210001',' ��̨����',19)";
		String sql02="insert into student02 values ('�Ŷ�','20210002',' ��̨����',20)";
		String sql03="insert into student02 values ('����','20210003',' ��̨����',21)";
		String sql04="insert into student02 values ('����','20210004',' ��̨����',22)";
		statement.executeUpdate(sql01);
		statement.executeUpdate(sql02);
		statement.executeUpdate(sql03);
		statement.executeUpdate(sql04);
		
		MysqlDemo.closeAll(null, statement, connect);
	}		
}
