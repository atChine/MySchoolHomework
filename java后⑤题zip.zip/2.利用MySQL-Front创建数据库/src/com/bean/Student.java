package com.bean;

public class Student {
	private String name;
	private String sno;
	private String addr;
	private int age;
	public Student(String name, String sno, String addr, int age) {
		super();
		this.name = name;
		this.sno = sno;
		this.addr = addr;
		this.age = age;
	}
	
	public Student() {
		super();
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
