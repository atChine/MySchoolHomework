package com.student;

public class TestStudent {
	public static void main(String[] args) {
		Student[] stu=new Student[10];
		Student[]students=new Student[2];
		for(int i=0;i<10;i++){
			stu[i]=new Student("������"+i+"��","2021000"+i,"����", 18+i);
		}
		int max=0;
		int min=0;
		max=min=stu[0].getAge();
		for(int i=0;i<stu.length;i++){
			if(stu[i].getAge()>max){
				max=stu[i].getAge();
				students[0]=stu[i];
			}
			if(stu[i].getAge()<=min){
				min=stu[i].getAge();
				students[1]=stu[i];
			}
		}
		System.out.println(students[0].toString());
		System.out.println(students[1].toString());
	}
}
