package com.student;

public  class Student {
	private String name;
	private String sno;
	private int age;
	private int score;
	
	public Student(String name, String sno, int age, int score) {
		super();
		this.name = name;
		this.sno = sno;
		this.age = age;
		this.score = score;
	}

	public Student() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", sno='" + sno + '\'' +
                ", age='" + age + '\'' +
                ", score='" + score + '\'' +
                '}';
    }

}
