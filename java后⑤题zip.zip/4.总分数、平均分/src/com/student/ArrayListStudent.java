package com.student;

import java.util.ArrayList;

public class ArrayListStudent {
	public static void main(String[] args) {
		ArrayList<Student> arrayList = new ArrayList<>();
		for(int i=0;i<10;i++){
			arrayList.add(new Student("������"+i+"��","2021000"+i,19, 80+i));
			double sum=0.0;
			for (Student student : arrayList) {
				sum=sum+student.getScore();
			}
			System.out.println("sum = "+sum);
			System.out.println("average = "+sum/arrayList.size());
		}	
	}
}
